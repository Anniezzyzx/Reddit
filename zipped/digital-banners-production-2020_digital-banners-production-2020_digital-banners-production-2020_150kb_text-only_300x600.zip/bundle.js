(function () {
  'use strict';

  // BannerUtils version 3.2.0
  function getBrowser() {
    // desktop browsers as of 2019-10-04
    var browserslist = ['other', 'blink', 'chrome', 'safari', 'opera', 'ie', 'edge', 'firefox'];
    var browser = 0;

    if ('WebkitAppearance' in document.documentElement.style) {
      browser = 1; // chrome/safari/opera/edge/firefox

      if (/google/i.test(window.navigator.vendor)) browser = 2;
      if (/apple/i.test(window.navigator.vendor)) browser = 3;
      if (!!window.opr && !!window.opr.addons || !!window.opera || / OPR\//.test(window.navigator.userAgent)) browser = 4;
    }

    if (
    /*@cc_on!@*/
     !!document.documentMode) browser = 5; // ie 6-11

    if (browser !== 5 && !!window.StyleMedia) browser = 6;
    if (typeof InstallTrigger !== 'undefined' || 'MozAppearance' in document.documentElement.style) browser = 7;
    return browserslist[browser];
  }
  var browser = getBrowser();
  function es5() {
    return parseInt('010', 10) === 10 && function () {
      return !this;
    }() && !!(Date && Date.prototype && Date.prototype.toISOString); // IE10, FF21, CH23, SF6, OP15, iOS7, AN4.4
  }
  var log = {
    // https://bit.ly/32ZIpgo
    traceOn: window.console.log.bind(window.console, '%s'),
    traceOff: function traceOff() {},
    trace: window.console.log.bind(window.console, '%s'),

    set debug(bool) {
      this._debug = bool;
      bool ? this.trace = this.traceOn : this.trace = this.traceOff;
    },

    get debug() {
      return this._debug;
    }

  };
  function domIds(scope) {
    if (scope === void 0) {
      scope = document;
    }

    var all = scope.getElementsByTagName('*');
    var haveIds = {};
    var i = all.length;

    while (i--) {
      if (all[i].id) {
        var safeId = all[i].id.replace(/-|:|\./g, '_');
        haveIds[safeId] = all[i];
      }
    }

    return haveIds;
  }

  var Banner = {
    init: function init() {
      var dom = domIds(); // Animation ---------------------------------------------------

      function display() {
        es5() ? animation() : dom.backup.classList.add('backup');

        function arrowUp() {
          var tl = gsap.timeline({
            defaults: {
              ease: 'sine.inOut'
            }
          });
          tl.to("#top_arrow", 0.2, {
            y: -6,
            yoyo: true,
            repeat: 1,
            ease: 'sine.Out'
          }).to(".cls-1", 0.5, {
            fill: "#ff4500"
          }, "-=0.6");
          dom.ad_content.classList.remove('invisible');
        }

        function cycle() {
          var tl = gsap.timeline({
            defaults: {
              ease: 'sine.inOut'
            }
          });
          tl.set(".cycletxt", {
            autoAlpha: 1
          }).from("#txt_3", 0.1, {
            rotateX: 90,
            ease: Cubic.easeOut
          }).call(arrowUp).to("#txt_3", 0.1, {
            rotateX: 90,
            ease: Cubic.easeOut
          }, "+=.2").from("#txt_4", 0.1, {
            rotateX: 90,
            ease: Cubic.easeOut
          }).call(arrowUp).to("#txt_4", 0.1, {
            rotateX: 90,
            ease: Cubic.easeOut
          }, "+=.2").from("#txt_5", 0.1, {
            rotateX: 90,
            ease: Cubic.easeOut
          }).call(arrowUp).to("#txt_5", 0.1, {
            rotateX: 90,
            ease: Cubic.easeOut
          }, "+=.2").from("#txt_6", 0.1, {
            rotateX: 90,
            ease: Cubic.easeOut
          }).call(arrowUp).to("#txt_6", 0.1, {
            rotateX: 90,
            ease: Cubic.easeOut
          }, "+=.2").from("#txt_7", 0.1, {
            rotateX: 90,
            ease: Cubic.easeOut
          });
        }

        function animation() {
          var tl = gsap.timeline({
            defaults: {
              ease: 'sine.inOut'
            }
          });
          tl.set(".cycletxt", {
            autoAlpha: 0
          }).staggerFrom(["#txt_1", "#txt_1b"], 0.01, {
            rotateX: -90,
            ease: Cubic.easeOut
          }, 0.5).call(cycle, this, "+=0.5").staggerFrom(["#txt_2", "#txt_2b"], 0.01, {
            rotateX: -90,
            ease: Cubic.easeOut
          }, 0.5, "+=2").from("#cta", 0.01, {
            autoAlpha: 0
          }, "+=0.5").call(rollover).from("#cta_arrow", 0.3, {
            scaleY: 0
          }).to("#cta_arrow", 0.2, {
            y: "-=2",
            repeat: 3,
            yoyo: true
          }).to("#cta_arrow", 0.2, {
            y: "-=2",
            repeat: 3,
            yoyo: true
          }, "+=2").to("#cta_arrow", 0.2, {
            y: "-=2",
            repeat: 3,
            yoyo: true
          }, "+=2");
          dom.ad_content.classList.remove('invisible');
        }
      } // Events ------------------------------------------------------


      function rollover() {
        dom.ad_content.addEventListener('mouseenter', function () {
          gsap.to('#cta_txt_black', 0.3, {
            autoAlpha: 0
          });
          gsap.to('#cta_txt_orange', 0.3, {
            autoAlpha: 1
          });
        });
        dom.ad_content.addEventListener('mouseleave', function () {
          gsap.to('#cta_txt_black', 0.3, {
            autoAlpha: 1
          });
          gsap.to('#cta_txt_orange', 0.3, {
            autoAlpha: 0
          });
        });
      }

      function clickThru() {
        dom.ad_content.addEventListener('click', function () {
          window.open(window.clickTag || window.clickTAG);
        });
      } // Init --------------------------------------------------------


      clickThru();
      display();
    }
  };

  window.onload = function () {
    window.requestAnimationFrame(Banner.init);
  };

}());
